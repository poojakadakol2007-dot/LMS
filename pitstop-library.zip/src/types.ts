export type UserRole = 'student' | 'employee' | 'admin';

export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  category: string;
  status: 'available' | 'borrowed';
  description?: string;
  imageUrl?: string;
  createdAt: any; // Firebase Timestamp
  updatedAt?: any;
}

export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
}

export interface UserAccount {
  id: string;
  email: string;
  role: UserRole;
  status: 'active' | 'suspended';
  joinedAt: any;
}

export interface Purchase {
  id: string;
  bookId: string;
  title: string;
  amount: number;
  quantity: number;
  paymentMethod: 'card' | 'upi' | 'cod';
  status: 'completed' | 'pending';
  purchasedAt: any;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}
