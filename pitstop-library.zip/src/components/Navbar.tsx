import { UserRole } from "../types";
import { Gauge, Users, ShieldCheck, LogOut, Library } from "lucide-react";
import { cn } from "../lib/utils";

interface NavbarProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
}

export default function Navbar({ currentRole, onRoleChange }: NavbarProps) {
  const roles: { id: UserRole; label: string; icon: any; color: string }[] = [
    { id: 'student', label: 'Student', icon: Library, color: 'bg-green-600' },
    { id: 'employee', label: 'Employee', icon: Gauge, color: 'bg-blue-700' },
    { id: 'admin', label: 'Admin', icon: ShieldCheck, color: 'bg-f1-red' },
  ];

  return (
    <nav className="flex flex-col sticky top-0 z-50">
      <div className="h-1.5 w-full bg-[#e10600]"></div>
      <div className="bg-f1-dark border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-8 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="text-3xl font-black tracking-tighter italic text-[#e10600]">
              KLE<span className="text-white">.LIB</span>
            </div>
            <div className="h-8 w-px bg-gray-700 hidden sm:block"></div>
            <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500 hidden lg:block">
              Technical Knowledge Starting Grid
            </div>
          </div>

          <div className="flex space-x-2 sm:space-x-4">
            {roles.map((role) => (
              <button
                key={role.id}
                onClick={() => onRoleChange(role.id)}
                className={cn(
                  "text-[10px] font-bold uppercase tracking-widest pb-1 transition-all",
                  currentRole === role.id 
                    ? "border-b-2 border-f1-red text-white" 
                    : "text-gray-500 hover:text-white"
                )}
              >
                {role.label} Portal
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}
