import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { name: 'JAN', volume: 400 },
  { name: 'FEB', volume: 300 },
  { name: 'MAR', volume: 600 },
  { name: 'APR', volume: 800 },
  { name: 'MAY', volume: 500 },
  { name: 'JUN', volume: 900 },
];

export default function Histogram() {
  return (
    <div className="h-64 w-full bg-[#1c1c24] p-4 border-l-4 border-f1-red">
      <div className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-4">
        Monthly Purchase Velocity // Telemetry
      </div>
      <ResponsiveContainer width="100%" height="80%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#333" />
          <XAxis 
            dataKey="name" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#666', fontSize: 10, fontWeight: 900 }} 
          />
          <YAxis hide />
          <Tooltip 
            contentStyle={{ backgroundColor: '#15151e', border: '1px solid #e10600', fontSize: 12, fontWeight: 900 }}
            itemStyle={{ color: '#fff' }}
            cursor={{ fill: 'rgba(255, 255, 255, 0.05)' }}
          />
          <Bar dataKey="volume" radius={[2, 2, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={index === data.length - 1 ? '#e10600' : '#38383f'} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
