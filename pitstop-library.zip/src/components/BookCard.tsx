import { motion } from "motion/react";
import { Book, UserRole } from "../types";
import { Trash2, Edit3, BookOpen, CheckCircle, XCircle, ShoppingBag } from "lucide-react";
import { cn } from "../lib/utils";

interface BookCardProps {
  book: Book;
  role: UserRole;
  onEdit?: (book: Book) => void;
  onDelete?: (id: string) => void;
  onPurchase?: (book: Book) => void;
  key?: string;
}

export default function BookCard({ book, role, onEdit, onDelete, onPurchase }: BookCardProps) {
  const isEmployee = role === 'employee' || role === 'admin';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={cn(
        "f1-card group",
        book.status === 'available' ? "border-blue-600" : "border-f1-red"
      )}
    >
      <div className="f1-card-number">{book.title.length}</div>
      
      <div className="relative mb-6">
        {book.imageUrl && (
          <div className="w-full aspect-video mb-4 overflow-hidden bg-f1-dark border border-gray-800">
            <img 
              src={book.imageUrl} 
              alt={book.title} 
              className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
              referrerPolicy="no-referrer"
            />
          </div>
        )}
        <div className="flex justify-between items-start mb-4">
          <span className="text-5xl font-black italic opacity-20 group-hover:opacity-100 group-hover:text-f1-red transition-all cursor-default">
            {book.isbn.slice(-2)}
          </span>
          <span className={cn(
            "text-[10px] font-black px-3 py-1 uppercase tracking-tighter",
            book.status === 'available' ? "bg-blue-600" : "bg-f1-red"
          )}>
            {book.category}
          </span>
        </div>

        <h3 className="text-2xl font-black uppercase leading-tight italic tracking-tighter mb-2">
          {book.title}
        </h3>
        <p className="text-xs text-gray-400 uppercase font-bold tracking-widest">
          {book.author}
        </p>
      </div>

      <div className="flex gap-2 mt-auto">
        {isEmployee ? (
          <>
            <button
              onClick={() => onEdit?.(book)}
              className="flex-1 bg-blue-700 hover:bg-blue-600 py-3 text-[10px] font-black uppercase tracking-tighter transition-all"
            >
              Update
            </button>
            <button
              onClick={() => onDelete?.(book.id)}
              className="flex-1 bg-f1-red hover:bg-[#ff1e1e] py-3 text-[10px] font-black uppercase tracking-tighter transition-all"
            >
              Delete
            </button>
          </>
        ) : (
          <button 
            onClick={() => onPurchase?.(book)}
            className="w-full bg-f1-gray hover:bg-white hover:text-black py-4 text-[10px] font-black uppercase tracking-tighter transition-all flex items-center justify-center gap-2 group"
          >
            <ShoppingBag className="w-4 h-4 group-hover:scale-110 transition-transform" />
            {book.status === 'available' ? 'Purchase Allocation' : 'Unavailable in Pits'}
          </button>
        )}
      </div>
    </motion.div>
  );
}
