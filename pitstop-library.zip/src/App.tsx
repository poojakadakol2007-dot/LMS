/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  setDoc,
  serverTimestamp, 
  query, 
  orderBy 
} from 'firebase/firestore';
import { signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import { db, auth } from './lib/firebase';
import { Book, UserRole, OperationType, Purchase } from './types';
import { cn } from './lib/utils';
import Navbar from './components/Navbar';
import BookCard from './components/BookCard';
import BookForm from './components/BookForm';
import PurchasePage from './components/PurchasePage';
import AdminDashboard from './components/AdminDashboard';
import { Plus, Search, Filter, Trophy, Gauge, Users, Library, ShoppingCart, LayoutDashboard } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export default function App() {
  const [role, setRole] = useState<UserRole>('student');
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [books, setBooks] = useState<Book[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [view, setView] = useState<'catalog' | 'purchase' | 'admin'>('catalog');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  // Sync Role
  useEffect(() => {
    // We'll skip mandatory auth for the prototype to avoid configuration hurdles
    if (auth.currentUser) {
      setAuthUser(auth.currentUser);
    }
  }, [role]);

  useEffect(() => {
    const q = query(collection(db, 'books'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const booksData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Book[];
      setBooks(booksData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'books');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'purchases'), orderBy('purchasedAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const purchaseData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Purchase[];
      setPurchases(purchaseData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'purchases');
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (role === 'admin') {
      setView('admin');
    } else {
      setView('catalog');
    }
  }, [role]);

  const filteredBooks = useMemo(() => {
    return books.filter(book => 
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [books, searchTerm]);

  const handleCreateBook = async (bookData: Partial<Book>) => {
    try {
      await addDoc(collection(db, 'books'), {
        ...bookData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setIsFormOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'books');
    }
  };

  const handleUpdateBook = async (bookData: Partial<Book>) => {
    if (!editingBook) return;
    try {
      const bookRef = doc(db, 'books', editingBook.id);
      await updateDoc(bookRef, {
        ...bookData,
        updatedAt: serverTimestamp(),
      });
      setIsFormOpen(false);
      setEditingBook(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `books/${editingBook.id}`);
    }
  };

  const handleDeleteBook = async (id: string) => {
    if (!window.confirm('Are you sure you want to retire this book from the active catalog?')) return;
    try {
      await deleteDoc(doc(db, 'books', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `books/${id}`);
    }
  };

  const openEditForm = (book: Book) => {
    setEditingBook(book);
    setIsFormOpen(true);
  };

  const handlePurchaseClick = (book: Book) => {
    setSelectedBook(book);
    setView('purchase');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePurchaseComplete = async (purchaseData: Partial<Purchase>) => {
    try {
      await addDoc(collection(db, 'purchases'), {
        ...purchaseData,
        purchasedAt: serverTimestamp(),
      });
      // Optionally update book status if it was unique, but for now just log it
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'purchases');
    }
  };

  const stats = useMemo(() => [
    { label: 'Total Logs', value: books.length, icon: Trophy, color: 'text-f1-red' },
    { label: 'Deployed', value: books.filter(b => b.status === 'available').length, icon: Gauge, color: 'text-blue-500' },
    { label: 'In Pits', value: books.filter(b => b.status === 'borrowed').length, icon: Users, color: 'text-yellow-500' },
  ], [books]);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar currentRole={role} onRoleChange={(r) => { setRole(r); setView('catalog'); }} />

      <main className="flex-grow max-w-7xl w-full mx-auto px-8 py-12">
        <AnimatePresence mode="wait">
          {view === 'catalog' && (
            <motion.div
              key="catalog"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {/* Hero Section */}
              <section className="mb-12">
                <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-12 border-l-4 border-f1-red pl-8">
                  <div>
                    <h1 className="f1-title-bold">Library Management<br/>Starting Grid</h1>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="text-4xl md:text-6xl font-black text-gray-800 italic select-none">KLE LIB // 01</div>
                    {(role === 'employee' || role === 'admin') && (
                      <div className="flex gap-4 mt-4">
                        {role === 'admin' && books.length === 0 && (
                          <button 
                            onClick={async () => {
                              const initialBooks = [
                                { title: "Aerodynamics: The Secret of Speed", author: "Adrian Newey", category: "Engineering", isbn: "ENG-F1-01", status: "available", description: "The definitive guide to fluid dynamics in high-speed racing systems." },
                                { title: "Distributed Telemetry Systems", author: "James Allison", category: "Computer Science", isbn: "CS-F1-01", status: "available", description: "Architecting real-time data pipelines for trackside analysis." },
                                { title: "Predictive Pit Strategy Algos", author: "Hannah Schmitz", category: "Computer Science", isbn: "CS-F1-02", status: "borrowed", description: "Using machine learning to optimize pit window timing." },
                                { title: "Carbon Fiber Composites", author: "John Barnard", category: "Engineering", isbn: "ENG-F1-02", status: "available", description: "Material science and structural integrity in lightweight chassis design." },
                                { title: "Kinetic Energy Recovery Systems", author: "Enrico Cardile", category: "Engineering", isbn: "ENG-F1-03", status: "available", description: "Hybrid power unit optimization and electrical deployment strategies." },
                                { title: "Low-Level Optimization for RTOS", author: "Rob Marshall", category: "Computer Science", isbn: "CS-F1-03", status: "available", description: "Maximizing throughput for engine control units and chassis sensors." },
                                { title: "Physics of Racing Lines", author: "Tino Belli", category: "Engineering", isbn: "ENG-F1-04", status: "available", description: "Mathematical modeling of tire contact patches and lateral G-forces." },
                                { title: "Secure Edge Computing", author: "Dan Fallows", category: "Computer Science", isbn: "CS-F1-04", status: "available", description: "Encryption and latency management in mobile trackside nodes." }
                              ];
                              for (const b of initialBooks) {
                                await addDoc(collection(db, 'books'), { ...b, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
                              }
                            }}
                            className="f1-button-blue flex items-center justify-center gap-3"
                          >
                            <Trophy className="w-5 h-5" />
                            <span className="tracking-widest">INITIALIZE STARTING GRID</span>
                          </button>
                        )}
                        <button 
                          onClick={() => { setEditingBook(null); setIsFormOpen(true); }}
                          className="f1-button-red flex items-center justify-center gap-4 group"
                        >
                          <span className="text-2xl group-hover:rotate-90 transition-transform">+</span>
                          <span className="tracking-widest">ADD NEW VOLUME</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Statistics Bar */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
                  {stats.map((stat, i) => (
                    <div key={i} className="border-t border-gray-700 pt-4">
                      <div className="text-[10px] uppercase font-black text-gray-500 tracking-[0.2em] mb-1">{stat.label}</div>
                      <div className={cn("text-4xl font-black italic tracking-tighter", stat.color)}>
                        {stat.value}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Search Bar */}
                <div className="relative mb-12">
                  <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-500 w-6 h-6" />
                  <input
                    type="text"
                    placeholder="SEARCH CATALOG BY TECHNICAL PARAMETERS..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-[#1c1c24] text-xl font-bold uppercase tracking-tighter p-6 pl-16 border-l-4 border-gray-700 focus:border-f1-red outline-none transition-all placeholder:text-gray-700"
                  />
                </div>
              </section>

              {/* Books Grid */}
              {loading ? (
                <div className="flex flex-col items-center justify-center py-20 gap-4">
                  <div className="w-12 h-12 border-4 border-f1-red border-t-transparent animate-spin rounded-full" />
                  <p className="f1-title text-xl animate-pulse">Syncing Telemetry...</p>
                </div>
              ) : filteredBooks.length > 0 ? (
                <motion.div 
                  layout
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
                >
                  <AnimatePresence mode="popLayout">
                    {filteredBooks.map((book) => (
                      <BookCard 
                        key={book.id} 
                        book={book} 
                        role={role} 
                        onEdit={openEditForm}
                        onDelete={handleDeleteBook}
                        onPurchase={handlePurchaseClick}
                      />
                    ))}
                  </AnimatePresence>
                </motion.div>
              ) : (
                <div className="text-center py-20 border-2 border-dashed border-gray-800 p-12">
                  <Library className="w-20 h-20 text-gray-800 mx-auto mb-6" />
                  <h3 className="text-3xl font-black uppercase italic italic text-gray-800 mb-2">No Records Found</h3>
                  <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">Technical parameters out of range.</p>
                </div>
              )}
            </motion.div>
          )}

          {view === 'purchase' && (
            <motion.div
              key="purchase"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {selectedBook && (
                <PurchasePage 
                  book={selectedBook}
                  onBack={() => setView('catalog')}
                  onComplete={handlePurchaseComplete}
                  recommendedBooks={books.filter(b => b.id !== selectedBook.id)}
                />
              )}
            </motion.div>
          )}

          {view === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3 }}
            >
              <AdminDashboard 
                books={books}
                purchases={purchases}
                onAddBook={() => { setEditingBook(null); setIsFormOpen(true); }}
                onEditBook={openEditForm}
                onDeleteBook={handleDeleteBook}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Branding */}
      <div className="bg-black px-8 py-4 flex justify-between items-center border-t border-gray-900 mt-20">
        <div className="text-[10px] font-bold text-gray-600 uppercase tracking-[0.2em]">
          Database Status: Optimal // Connection Established
        </div>
        <div className="flex items-center space-x-4">
           <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
           <span className="text-[10px] font-bold text-gray-600 uppercase tracking-[0.2em]">KLE Node Alpha-01</span>
        </div>
      </div>

      {/* Modals */}
      <BookForm 
        isOpen={isFormOpen}
        onClose={() => { setIsFormOpen(false); setEditingBook(null); }}
        onSubmit={editingBook ? handleUpdateBook : handleCreateBook}
        initialData={editingBook}
      />
    </div>
  );
}
