import { motion, AnimatePresence } from "motion/react";
import { Book, UserRole } from "../types";
import { X, Send, BookMarked, Layers, User2, Hash, Image as ImageIcon, AlignLeft } from "lucide-react";
import React, { useState, useEffect } from "react";

interface BookFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (book: Partial<Book>) => void;
  initialData?: Book | null;
}

export default function BookForm({ isOpen, onClose, onSubmit, initialData }: BookFormProps) {
  const [formData, setFormData] = useState<Partial<Book>>({
    title: '',
    author: '',
    isbn: '',
    category: '',
    status: 'available',
    description: '',
    imageUrl: ''
  });

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        title: '',
        author: '',
        isbn: '',
        category: '',
        status: 'available',
        description: '',
        imageUrl: ''
      });
    }
  }, [initialData, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-f1-dark/80 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ scale: 0.9, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: 20, opacity: 0 }}
            className="relative w-full max-w-2xl bg-[#1f1f27] border-t-8 border-f1-red p-8 shadow-2xl overflow-hidden"
            style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 30px), calc(100% - 30px) 100%, 0 100%)' }}
          >
            <div className="absolute top-0 right-0 p-4">
              <button 
                onClick={onClose}
                className="p-2 hover:bg-white hover:text-f1-dark transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="mb-8">
              <h2 className="f1-title text-3xl mb-1">{initialData ? 'Update Book' : 'Add New Book'}</h2>
              <p className="text-gray-400 text-sm">Enter the technical specifications for the library catalog.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-f1-red flex items-center gap-2">
                    <BookMarked className="w-3 h-3" /> Book Title
                  </label>
                  <input
                    required
                    value={formData.title}
                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                    className="f1-input w-full"
                    placeholder="E.g. Engineering Mechanics"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-f1-red flex items-center gap-2">
                    <User2 className="w-3 h-3" /> Author
                  </label>
                  <input
                    required
                    value={formData.author}
                    onChange={e => setFormData({ ...formData, author: e.target.value })}
                    className="f1-input w-full"
                    placeholder="E.g. J.L. Meriam"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-f1-red flex items-center gap-2">
                    <Hash className="w-3 h-3" /> ISBN
                  </label>
                  <input
                    required
                    value={formData.isbn}
                    onChange={e => setFormData({ ...formData, isbn: e.target.value })}
                    className="f1-input w-full"
                    placeholder="978-3-16-148410-0"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-f1-red flex items-center gap-2">
                    <Layers className="w-3 h-3" /> Category
                  </label>
                  <input
                    required
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value })}
                    className="f1-input w-full"
                    placeholder="E.g. Physics"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-wider text-f1-red flex items-center gap-2">
                  <ImageIcon className="w-3 h-3" /> Cover Image URL
                </label>
                <input
                  value={formData.imageUrl}
                  onChange={e => setFormData({ ...formData, imageUrl: e.target.value })}
                  className="f1-input w-full"
                  placeholder="https://example.com/cover.jpg"
                />
                {formData.imageUrl && (
                  <div className="mt-2 w-full h-32 border border-gray-800 bg-f1-dark overflow-hidden">
                    <img 
                      src={formData.imageUrl} 
                      alt="Preview" 
                      className="w-full h-full object-contain"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://placehold.co/400x300/15151e/e10600?text=Invalid+Image+URL';
                      }}
                    />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-wider text-f1-red flex items-center gap-2">
                  <AlignLeft className="w-3 h-3" /> Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="f1-input w-full h-32 resize-none"
                  placeholder="Technical summary of the content..."
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="submit"
                  className="f1-button-red flex-1 flex items-center justify-center gap-3"
                >
                  <Send className="w-4 h-4" />
                  <span className="tracking-tighter">{initialData ? 'UPDATE TECHNICAL DATA' : 'DEPLOY TO CATALOG'}</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="f1-button-blue px-8"
                >
                  <span>ABORT</span>
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
