import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Book as BookIcon, 
  Users as UsersIcon, 
  CreditCard, 
  BarChart3, 
  Plus, 
  Search, 
  MoreVertical, 
  TrendingUp, 
  ChevronRight,
  Settings,
  Bell,
  Trash2,
  Edit3
} from 'lucide-react';
import { Book, Purchase, UserAccount, UserRole } from '../types';
import { cn } from '../lib/utils';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

interface AdminDashboardProps {
  books: Book[];
  purchases: Purchase[];
  onAddBook: () => void;
  onEditBook: (book: Book) => void;
  onDeleteBook: (id: string) => void;
}

const chartData = [
  { name: 'Mon', revenue: 2400, transactions: 400 },
  { name: 'Tue', revenue: 1398, transactions: 300 },
  { name: 'Wed', revenue: 9800, transactions: 2000 },
  { name: 'Thu', revenue: 3908, transactions: 2780 },
  { name: 'Fri', revenue: 4800, transactions: 1890 },
  { name: 'Sat', revenue: 3800, transactions: 2390 },
  { name: 'Sun', revenue: 4300, transactions: 3490 },
];

export default function AdminDashboard({ books, purchases, onAddBook, onEditBook, onDeleteBook }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'books' | 'users' | 'payments'>('overview');
  const [searchTerm, setSearchTerm] = useState('');

  const stats = useMemo(() => {
    const totalRevenue = purchases.reduce((acc, p) => acc + (p.amount || 0), 0);
    const issuedBooks = books.filter(b => b.status === 'borrowed').length;
    
    return [
      { label: 'Total Volumes', value: books.length, icon: BookIcon, color: 'text-blue-500', bg: 'bg-blue-500/10' },
      { label: 'Active Analysts', value: 124, icon: UsersIcon, color: 'text-purple-500', bg: 'bg-purple-500/10' },
      { label: 'Issued Logistics', value: issuedBooks, icon: TrendingUp, color: 'text-orange-500', bg: 'bg-orange-500/10' },
      { label: 'Total Revenue', value: `$${totalRevenue.toFixed(2)}`, icon: CreditCard, color: 'text-green-500', bg: 'bg-green-500/10' },
    ];
  }, [books, purchases]);

  return (
    <div className="flex h-[calc(100vh-140px)] gap-8">
      {/* Sidebar Navigation */}
      <div className="w-64 bg-[#15151e]/50 backdrop-blur-xl border border-white/5 p-6 flex flex-col gap-8 rounded-2xl">
        <div className="space-y-1">
          <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest px-4 mb-4">Command Center</p>
          {[
            { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'books', label: 'Book Inventory', icon: BookIcon },
            { id: 'users', label: 'User Grid', icon: UsersIcon },
            { id: 'payments', label: 'Transactions', icon: CreditCard },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                "w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all font-bold text-sm",
                activeTab === item.id 
                  ? "bg-f1-red text-white shadow-lg shadow-f1-red/20" 
                  : "text-gray-500 hover:text-white hover:bg-white/5"
              )}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </div>

        <div className="mt-auto space-y-1">
          <button className="w-full flex items-center gap-4 px-4 py-3 text-gray-500 hover:text-white transition-all font-bold text-sm">
            <Settings className="w-5 h-5" />
            System Settings
          </button>
          <button className="w-full flex items-center gap-4 px-4 py-3 text-gray-500 hover:text-white transition-all font-bold text-sm">
            <Bell className="w-5 h-5" />
            Alerts Log
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col gap-8 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-4xl font-black uppercase italic tracking-tighter">
              {activeTab === 'overview' && 'System Telemetry'}
              {activeTab === 'books' && 'Inventory Control'}
              {activeTab === 'users' && 'Personnel Management'}
              {activeTab === 'payments' && 'Financial Ledger'}
            </h2>
            <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">
              Secure Operations // Admin Node 01
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search resources..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-[#1c1c24]/50 backdrop-blur-md border border-white/5 rounded-xl pl-12 pr-4 py-2.5 text-sm outline-none focus:border-f1-red/50 transition-all w-64"
              />
            </div>
          </div>
        </div>

        {/* Content Render */}
        <div className="flex-1 overflow-y-auto no-scrollbar pb-8">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && (
              <motion.div 
                key="overview"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  {stats.map((stat, i) => (
                    <div key={i} className="bg-[#1c1c24]/50 backdrop-blur-xl border border-white/5 p-6 rounded-2xl group hover:border-f1-red/30 transition-all">
                      <div className="flex justify-between items-start mb-4">
                        <div className={cn("p-3 rounded-xl", stat.bg)}>
                          <stat.icon className={cn("w-6 h-6", stat.color)} />
                        </div>
                        <span className="text-[10px] font-black text-green-500 bg-green-500/10 px-2 py-0.5 rounded-full">+12.5%</span>
                      </div>
                      <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">{stat.label}</p>
                      <h3 className="text-3xl font-black italic tracking-tighter">{stat.value}</h3>
                    </div>
                  ))}
                </div>

                {/* Analytical Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-[#1c1c24]/50 backdrop-blur-xl border border-white/5 p-8 rounded-3xl">
                    <div className="flex justify-between items-center mb-8">
                      <h4 className="text-xl font-black uppercase italic tracking-tighter">Revenue Trajectory</h4>
                      <div className="flex gap-2">
                        <button className="text-[10px] font-black uppercase bg-white/5 px-3 py-1 rounded-full text-gray-400">7 Days</button>
                        <button className="text-[10px] font-black uppercase bg-f1-red px-3 py-1 rounded-full text-white">30 Days</button>
                      </div>
                    </div>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={chartData}>
                          <defs>
                            <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#e10600" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#e10600" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#666', fontSize: 10, fontWeight: 900 }} />
                          <YAxis hide />
                          <Tooltip contentStyle={{ backgroundColor: '#15151e', border: '1px solid #e10600', borderRadius: '12px', fontSize: '10px' }} />
                          <Area type="monotone" dataKey="revenue" stroke="#e10600" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={3} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="bg-[#1c1c24]/50 backdrop-blur-xl border border-white/5 p-8 rounded-3xl">
                    <div className="flex justify-between items-center mb-8">
                      <h4 className="text-xl font-black uppercase italic tracking-tighter">Daily Acquisitions</h4>
                      <BarChart3 className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#666', fontSize: 10, fontWeight: 900 }} />
                          <YAxis hide />
                          <Tooltip cursor={{ fill: 'rgba(255,255,255,0.05)' }} contentStyle={{ backgroundColor: '#15151e', border: 'none', borderRadius: '12px', fontSize: '10px' }} />
                          <Bar dataKey="transactions" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={20} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'books' && (
              <motion.div 
                key="books"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-4"
              >
                <div className="flex justify-between items-center mb-4">
                  <h4 className="text-lg font-black uppercase tracking-widest text-gray-400">Inventory Registry</h4>
                  <button 
                    onClick={onAddBook}
                    className="f1-button-red flex items-center gap-2 py-2 px-4 text-xs"
                  >
                    <Plus className="w-4 h-4" />
                    ADD NEW VOLUME
                  </button>
                </div>
                <div className="bg-[#1c1c24]/50 backdrop-blur-xl border border-white/5 rounded-2xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-white/5 bg-white/5 text-[10px] font-black uppercase tracking-widest text-gray-500">
                        <th className="px-6 py-4">Serial / ISBN</th>
                        <th className="px-6 py-4">Technical Volume</th>
                        <th className="px-6 py-4">Author / Architect</th>
                        <th className="px-6 py-4">Category</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {books.map((book) => (
                        <tr key={book.id} className="hover:bg-white/5 transition-colors group">
                          <td className="px-6 py-4 font-mono text-[10px] text-gray-500">{book.isbn}</td>
                          <td className="px-6 py-4">
                            <div className="font-black italic uppercase text-sm">{book.title}</div>
                          </td>
                          <td className="px-6 py-4 text-xs font-bold text-gray-400">{book.author}</td>
                          <td className="px-6 py-4">
                            <span className="text-[10px] font-black text-blue-500 bg-blue-500/10 px-2 py-0.5 rounded-full uppercase italic hover:bg-blue-500 hover:text-white transition-all cursor-default">
                              {book.category}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className={cn(
                              "text-[10px] font-black uppercase tracking-widest flex items-center gap-2",
                              book.status === 'available' ? 'text-green-500' : 'text-f1-red'
                            )}>
                              <div className={cn("w-1.5 h-1.5 rounded-full", book.status === 'available' ? 'bg-green-500' : 'bg-f1-red')} />
                              {book.status}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button onClick={() => onEditBook(book)} className="p-2 hover:bg-white/10 rounded-lg transition-all text-gray-400 hover:text-white">
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button onClick={() => onDeleteBook(book.id)} className="p-2 hover:bg-f1-red/20 rounded-lg transition-all text-gray-400 hover:text-f1-red">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* Other tabs user grid and payments can be added similarly */}
            {activeTab === 'users' && (
               <div className="flex flex-col items-center justify-center py-20 text-gray-500 border-2 border-dashed border-white/5 rounded-3xl">
                  <UsersIcon className="w-12 h-12 mb-4 opacity-20" />
                  <p className="font-black uppercase tracking-widest text-xs">User Database Offline</p>
               </div>
            )}

            {activeTab === 'payments' && (
              <motion.div 
                key="payments"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-4"
              >
                <div className="bg-[#1c1c24]/50 backdrop-blur-xl border border-white/5 rounded-2xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-white/5 bg-white/5 text-[10px] font-black uppercase tracking-widest text-gray-500">
                        <th className="px-6 py-4">Transaction ID</th>
                        <th className="px-6 py-4">Volume</th>
                        <th className="px-6 py-4">Amount</th>
                        <th className="px-6 py-4">Quantity</th>
                        <th className="px-6 py-4">Protocol</th>
                        <th className="px-6 py-4">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {purchases.map((purchase) => (
                        <tr key={purchase.id} className="hover:bg-white/5 transition-colors">
                          <td className="px-6 py-4 font-mono text-[10px] text-gray-500 uppercase">{purchase.id.slice(-8)}</td>
                          <td className="px-6 py-4 font-black italic uppercase text-sm">{purchase.title}</td>
                          <td className="px-6 py-4 font-bold text-white">${purchase.amount.toFixed(2)}</td>
                          <td className="px-6 py-4 text-xs font-bold text-gray-400">{purchase.quantity}</td>
                          <td className="px-6 py-4">
                            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">
                              {purchase.paymentMethod}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-[10px] font-black text-green-500 border border-green-500/20 px-2 py-0.5 rounded uppercase">
                              {purchase.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                      {purchases.length === 0 && (
                        <tr>
                          <td colSpan={6} className="px-6 py-12 text-center text-gray-500 font-bold uppercase tracking-widest text-xs">
                            No active transactions recorded.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
