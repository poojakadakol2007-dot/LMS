import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Book, Purchase, OperationType } from '../types';
import { CreditCard, Smartphone, Truck, CheckCircle2, ChevronRight, ArrowLeft, Ticket, ShoppingBag, Star } from 'lucide-react';
import { cn } from '../lib/utils';
import Histogram from './Histogram';

interface PurchasePageProps {
  book: Book;
  onBack: () => void;
  onComplete: (purchase: Partial<Purchase>) => void;
  recommendedBooks: Book[];
}

export default function PurchasePage({ book, onBack, onComplete, recommendedBooks }: PurchasePageProps) {
  const [quantity, setQuantity] = useState(1);
  const [coupon, setCoupon] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'cod'>('card');
  const [isSuccess, setIsSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const pricePerUnit = 249.99;
  const discount = coupon.toUpperCase() === 'GRID10' ? 0.1 : 0;
  const subtotal = pricePerUnit * quantity;
  const total = subtotal * (1 - discount);

  const handlePayment = () => {
    setIsLoading(true);
    // Simulate payment validation and processing
    setTimeout(() => {
      setIsLoading(false);
      setIsSuccess(true);
      onComplete({
        bookId: book.id,
        title: book.title,
        amount: total,
        quantity: quantity,
        paymentMethod: paymentMethod,
        status: 'completed',
      });
    }, 2000);
  };

  if (isSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center py-20 text-center"
      >
        <div className="w-24 h-24 bg-green-600 flex items-center justify-center mb-8 rotate-12">
          <CheckCircle2 className="w-12 h-12 text-white -rotate-12" />
        </div>
        <h2 className="text-6xl font-black uppercase italic tracking-tighter mb-4">Transaction Confirmed</h2>
        <p className="text-gray-400 font-bold uppercase tracking-widest text-sm mb-12 max-w-md">
          The technical volume has been successfully allocated to your collection. 
          Deployment will commence within the next logistics window.
        </p>
        <button onClick={onBack} className="f1-button-red px-12">
          RETURN TO STARTING GRID
        </button>
      </motion.div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
      {/* Checkout Section */}
      <div className="lg:col-span-8">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 hover:text-white transition-colors mb-8 group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span className="text-[10px] font-black uppercase tracking-widest">Back to Catalog</span>
        </button>

        <div className="border-l-4 border-f1-red pl-8 mb-12">
          <h2 className="text-5xl font-black uppercase italic tracking-tighter mb-2">Technical Procurement</h2>
          <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">Secure Transaction Interface v2.4</p>
        </div>

        <div className="space-y-12">
          {/* Item Details */}
          <div className="bg-[#1c1c24] p-8 border border-gray-800 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4">
              <span className="text-[10px] font-black text-f1-red uppercase tracking-widest">In Stock // Optimal</span>
            </div>
            <div className="flex gap-8 items-start">
              <div className="w-32 aspect-[3/4] bg-f1-gray flex items-center justify-center">
                <ShoppingBag className="w-12 h-12 text-gray-700" />
              </div>
              <div>
                <h3 className="text-3xl font-black uppercase italic tracking-tighter mb-2">{book.title}</h3>
                <p className="text-gray-400 font-bold text-sm mb-6">{book.author}</p>
                
                <div className="flex items-center gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest block">Unit Velocity (Qty)</label>
                    <div className="flex items-center gap-4 bg-f1-dark p-2 border border-gray-800">
                      <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="px-3 hover:text-f1-red transition-colors text-xl font-black">-</button>
                      <span className="text-xl font-black w-8 text-center">{quantity}</span>
                      <button onClick={() => setQuantity(quantity + 1)} className="px-3 hover:text-f1-red transition-colors text-xl font-black">+</button>
                    </div>
                  </div>
                  <div className="h-10 w-px bg-gray-800 self-end mb-2" />
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest block">Unit Valuation</label>
                    <p className="text-2xl font-black italic">${pricePerUnit}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-6">
            <h4 className="text-xl font-black uppercase italic tracking-tighter border-b border-gray-800 pb-4 flex items-center gap-3">
              <CreditCard className="w-5 h-5 text-f1-red" />
              Payment Protocol
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { id: 'card', label: 'Credit Card', icon: CreditCard },
                { id: 'upi', label: 'UPI / Digital', icon: Smartphone },
                { id: 'cod', label: 'Cash on Pits (COD)', icon: Truck },
              ].map((method) => (
                <button
                  key={method.id}
                  onClick={() => setPaymentMethod(method.id as any)}
                  className={cn(
                    "flex flex-col items-start gap-4 p-6 border transition-all relative overflow-hidden",
                    paymentMethod === method.id 
                      ? "bg-f1-red border-f1-red text-white" 
                      : "bg-[#1c1c24] border-gray-800 text-gray-500 hover:border-f1-red hover:text-white"
                  )}
                >
                  <method.icon className="w-8 h-8" />
                  <span className="text-[10px] font-black uppercase tracking-widest">{method.label}</span>
                  {paymentMethod === method.id && (
                    <motion.div layoutId="payment-active" className="absolute top-2 right-2">
                       <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                    </motion.div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Recently Purchased (Horizontal Scroll) */}
          <div className="space-y-6">
            <h4 className="text-xl font-black uppercase italic tracking-tighter border-b border-gray-800 pb-4 flex items-center gap-3">
              <Star className="w-5 h-5 text-yellow-500" />
              Recent Allocations
            </h4>
            <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
              {recommendedBooks.slice(0, 4).map((recBook, i) => (
                <div key={i} className="min-w-[200px] bg-[#1c1c24] p-4 border-l-2 border-gray-700">
                  <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Book ID: {recBook.isbn.slice(-4)}</p>
                  <h5 className="text-sm font-black uppercase italic truncate mb-1">{recBook.title}</h5>
                  <p className="text-[10px] text-f1-red font-bold uppercase italic">Allocated</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Summary Sidebar */}
      <div className="lg:col-span-4 space-y-8">
        <div className="bg-[#1c1c24] p-8 border border-gray-800 sticky top-32">
          <h4 className="text-2xl font-black uppercase italic tracking-tighter mb-8 border-b border-gray-800 pb-4">
            Subtotal Telemetry
          </h4>
          
          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-gray-400">
              <span className="text-[10px] font-black uppercase tracking-widest">Base Valuation</span>
              <span className="font-bold">${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-gray-400">
              <span className="text-[10px] font-black uppercase tracking-widest">Logistics / Shipping</span>
              <span className="font-bold text-green-500">FREE</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-f1-red">
                <span className="text-[10px] font-black uppercase tracking-widest">Grid Discount (10%)</span>
                <span className="font-bold">-${(subtotal * discount).toFixed(2)}</span>
              </div>
            )}
            <div className="pt-4 border-t border-gray-800 flex justify-between items-end">
              <span className="text-[10px] font-black uppercase tracking-widest mb-1">Total Payload</span>
              <span className="text-4xl font-black italic text-white">${total.toFixed(2)}</span>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-2">
                <Ticket className="w-3 h-3" /> Grid Coupon Code
              </label>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                  placeholder="CODE..."
                  className="bg-f1-dark border border-gray-800 text-white font-black text-sm p-3 flex-grow outline-none focus:border-f1-red transition-all"
                />
              </div>
              <p className="text-[8px] font-bold text-gray-600 italic">HINT: Try 'GRID10' for discount.</p>
            </div>

            <button 
              onClick={handlePayment}
              disabled={isLoading}
              className="w-full f1-button-red h-16 flex items-center justify-center gap-4 group"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent animate-spin" />
              ) : (
                <>
                  <span className="tracking-widest">EXECUTE PAYMENT</span>
                  <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
            <p className="text-[8px] font-bold text-center text-gray-600 uppercase tracking-widest">
              Secured by KLE Encryption Protocols // AES-256
            </p>
          </div>
        </div>

        {/* Telemetry Chart */}
        <Histogram />
      </div>
    </div>
  );
}
